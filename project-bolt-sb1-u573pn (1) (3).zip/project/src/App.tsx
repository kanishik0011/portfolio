import React from 'react';
import { Code2, Briefcase, Trophy, GraduationCap, Github, Linkedin, Mail, BookOpen } from 'lucide-react';
import ProjectCard from './components/ProjectCard';
import SkillBadge from './components/SkillBadge';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-16 flex flex-col items-center text-center">
        <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
          Kanishik Sai Koshik
        </h1>
        <p className="text-xl text-gray-300 mb-8">Computer Science & Business Systems Student</p>
        <div className="flex gap-4">
          <a href="https://www.linkedin.com/in/kanishk-sai-kaushik-6a6945272/" className="hover:text-blue-400 transition-colors">
            <Linkedin className="w-6 h-6" />
          </a>
          <a href="mailto:kanishkkaushik78@gmail.com" className="hover:text-blue-400 transition-colors">
            <Mail className="w-6 h-6" />
          </a>
          <a href="https://github.com" className="hover:text-blue-400 transition-colors">
            <Github className="w-6 h-6" />
          </a>
        </div>
      </header>

      {/* Education Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex items-center gap-2 mb-8">
          <GraduationCap className="w-8 h-8 text-blue-400" />
          <h2 className="text-3xl font-bold">Education</h2>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-6 backdrop-blur-sm">
          <h3 className="text-xl font-semibold">GYAN GANGA INSTITUTE OF TECHNOLOGY AND SCIENCE (GGITS)</h3>
          <p className="text-gray-300">Bachelor of Technology in Computer Science and Business System</p>
          <p className="text-blue-400">2022-2026</p>
          <p className="text-gray-300">CGPA: 7.51</p>
        </div>
      </section>

      {/* Projects Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex items-center gap-2 mb-8">
          <Code2 className="w-8 h-8 text-blue-400" />
          <h2 className="text-3xl font-bold">Projects</h2>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <ProjectCard 
            title="Animated Website"
            description="Interactive web platform with 3D transitions and responsive design"
            tech={['HTML', 'CSS', 'JavaScript']}
          />
          <ProjectCard 
            title="Tele AI-based Healthcare"
            description="AI-powered telehealth platform with virtual check-ups and consultations"
            tech={['React', 'Node.js', 'JavaScript']}
          />
          <ProjectCard 
            title="Smart AI-based Traffic System"
            description="Automated traffic management using real-time camera detection"
            tech={['Python', 'DSA', 'OpenCV']}
          />
        </div>
      </section>

      {/* Skills Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex items-center gap-2 mb-8">
          <BookOpen className="w-8 h-8 text-blue-400" />
          <h2 className="text-3xl font-bold">Skills</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          <SkillBadge title="Languages" items={['C++', 'Python', 'Java']} />
          <SkillBadge title="Web" items={['React', 'Node.js', 'Express.js']} />
          <SkillBadge title="Core" items={['DSA', 'DBMS', 'OOPS']} />
          <SkillBadge title="Tools" items={['VS Code', 'PyCharm', 'Git']} />
        </div>
      </section>

      {/* Achievements Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex items-center gap-2 mb-8">
          <Trophy className="w-8 h-8 text-blue-400" />
          <h2 className="text-3xl font-bold">Achievements</h2>
        </div>
        <ul className="space-y-4">
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 mt-2 rounded-full bg-blue-400"></div>
            <p className="text-gray-300">Global Rank 2266 in TCS CodeVita Season 11</p>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 mt-2 rounded-full bg-blue-400"></div>
            <p className="text-gray-300">Solved 250+ LeetCode problems with a 179-day streak</p>
          </li>
        </ul>
      </section>
    </div>
  );
}

export default App;