import React from 'react';

interface ProjectCardProps {
  title: string;
  description: string;
  tech: string[];
}

const ProjectCard: React.FC<ProjectCardProps> = ({ title, description, tech }) => {
  return (
    <div className="bg-gray-800/50 rounded-lg p-6 backdrop-blur-sm transform hover:scale-105 transition-transform">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-300 mb-4">{description}</p>
      <div className="flex flex-wrap gap-2">
        {tech.map((item, index) => (
          <span 
            key={index}
            className="px-3 py-1 text-sm bg-blue-500/20 text-blue-300 rounded-full"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

export default ProjectCard;