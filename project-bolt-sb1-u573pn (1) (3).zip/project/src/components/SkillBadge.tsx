import React from 'react';

interface SkillBadgeProps {
  title: string;
  items: string[];
}

const SkillBadge: React.FC<SkillBadgeProps> = ({ title, items }) => {
  return (
    <div className="bg-gray-800/50 rounded-lg p-6 backdrop-blur-sm">
      <h3 className="text-lg font-semibold mb-3 text-blue-400">{title}</h3>
      <div className="flex flex-wrap gap-2">
        {items.map((item, index) => (
          <span 
            key={index}
            className="px-3 py-1 text-sm bg-gray-700/50 text-gray-300 rounded-full"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

export default SkillBadge;